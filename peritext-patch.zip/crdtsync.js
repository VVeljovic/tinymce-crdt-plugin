tinymce.PluginManager.add("crdtsync", function (editor) {
  editor.options.register("crdtsync_hub_url", {
    processor: "string",
    default: "default",
  });
  editor.options.register("crdtsync_doc_id", {
    processor: "string",
    default: "default",
  });
  const hubUrl = editor.options.get("crdtsync_hub_url");
  const docId = editor.options.get("crdtsync_doc_id");

  // NOVO: koji mark tipovi rastu na granici spana kad se ubaci novi tekst (Sekcija 4.2.2 /
  // Primeri 7-8 u Peritext radu). Mora da odgovara MarkTypes registru u CrdtCore/MarkTypes.cs.
  const MARK_BEHAVIOR = {
    bold: "expanding",
    italic: "expanding",
    underline: "expanding",
    color: "expanding",
    link: "nonExpanding",
  };

  function getOrCreateNodeId() {
    let id = localStorage.getItem("crdtsync_node_id");
    if (!id) {
      id = Math.floor(Math.random() * 1000000);
      localStorage.setItem("crdtsync_node_id", id);
    }

    return parseInt(id, 10);
  }

  let connection = null;
  let isApplyingRemoteChange = false;

  const myNodeId = getOrCreateNodeId();
  let myCounter = 0;
  let localElements = [];
  let localMarks = [];
  // NOVO: poslednje formatiranje koje je IZRACUNAO SERVER (CrdtFormatting.ComputeSpans).
  // Namerno ne racunamo ovo ponovo u JS-u - server ostaje jedini izvor istine, klijent samo
  // renderuje spans i koristi ih za "da li je selekcija vec bold" proveru pri toggle-u.
  let localSpans = [];

  function findPredecessorId(visibleIndex) {
    if (visibleIndex === 0) {
      return null;
    }

    let visibleCount = 0;
    for (const el of localElements) {
      if (el.isDeleted) {
        continue;
      }
      visibleCount++;
      if (visibleCount === visibleIndex) {
        return el.crdtId;
      }
    }

    const last = [...localElements].reverse().find((e) => !e.isDeleted);
    return last ? last.crdtId : null;
  }

  function findVisibleElementAt(visibleIndex) {
    let visibleCount = -1;
    for (const el of localElements) {
      if (el.isDeleted) continue;
      visibleCount++;
      if (visibleCount === visibleIndex) return el;
    }
    return null;
  }

  // NOVO: CrdtId vidljivog karaktera na datom indeksu (0-based, samo ne-obrisani karakteri).
  function crdtIdAtVisibleIndex(visibleIndex) {
    const el = findVisibleElementAt(visibleIndex);
    return el ? el.crdtId : null;
  }

  function idsEqual(a, b) {
    return a && b && a.nodeId === b.nodeId && a.counter === b.counter;
  }

  function renderText() {
    return localElements
      .filter((e) => !e.isDeleted)
      .map((e) => e.value)
      .join("");
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // NOVO: pretvara formatted spans (dobijene od servera) u HTML. Napomena: Peritext pokriva
  // samo inline formatiranje (Sekcija 1 u radu) - paragraf/block split ovde i dalje radimo
  // naivno na osnovu '\n' karaktera, kao i pre ovog patch-a.
  function wrapWithMarks(html, marks) {
    if (marks.link) html = `<a href="${escapeHtml(marks.link)}">${html}</a>`;
    if (marks.underline) html = `<u>${html}</u>`;
    if (marks.italic) html = `<em>${html}</em>`;
    if (marks.bold) html = `<strong>${html}</strong>`;
    if (marks.color) html = `<span style="color:${escapeHtml(marks.color)}">${html}</span>`;
    return html;
  }

  function spansToHtml(spans) {
    const lines = [];
    let currentLine = "";

    function flushLine() {
      lines.push(currentLine.length ? currentLine : "<br>");
      currentLine = "";
    }

    for (const span of spans) {
      const parts = span.text.split("\n");
      parts.forEach((part, i) => {
        if (i > 0) flushLine();
        if (part.length === 0) return;
        currentLine += wrapWithMarks(escapeHtml(part), span.marks || {});
      });
    }
    flushLine();

    return lines.map((l) => `<p>${l}</p>`).join("");
  }

  function diffText(oldText, newText) {
    let start = 0;
    while (
      start < oldText.length &&
      start < newText.length &&
      oldText[start] == newText[start]
    ) {
      start++;
    }

    let oldEnd = oldText.length;
    let newEnd = newText.length;

    while (
      oldEnd > start &&
      newEnd > start &&
      oldText[oldEnd - 1] == newText[newEnd - 1]
    ) {
      oldEnd--;
      newEnd--;
    }

    return {
      start,
      deleted: oldText.slice(start, oldEnd),
      inserted: newText.slice(start, newEnd),
    };
  }

  // NOVO: offset selekcije u ravnom tekstu editora (isti tekst koji renderText()/diffText
  // koriste), racunat preko Range-ova. Standardan trik za mapiranje DOM selekcije u
  // plain-text indeks kad se editor svakako tretira kao flat niz karaktera.
  function getSelectionTextOffsets() {
    const rng = editor.selection.getRng();
    const body = editor.getBody();

    const preStart = rng.cloneRange();
    preStart.selectNodeContents(body);
    preStart.setEnd(rng.startContainer, rng.startOffset);
    const start = preStart.toString().length;

    const preEnd = rng.cloneRange();
    preEnd.selectNodeContents(body);
    preEnd.setEnd(rng.endContainer, rng.endOffset);
    const end = preEnd.toString().length;

    return { start, end };
  }

  // NOVO: da li je CEO opseg [startIdx, endIdxExclusive) vec pod datim markType-om, koristi
  // se za toggle logiku (dugme Bold treba da UKLONI bold ako je sve vec bold, inace da DODA).
  function isRangeFullyMarked(startIdx, endIdxExclusive, markType) {
    let pos = 0;
    for (const span of localSpans) {
      const len = span.text.length;
      const spanStart = pos;
      const spanEnd = pos + len;
      if (spanEnd > startIdx && spanStart < endIdxExclusive) {
        if (!span.marks || !span.marks[markType]) return false;
      }
      pos = spanEnd;
    }
    return true;
  }

  function makeOpId() {
    return { nodeId: myNodeId, counter: myCounter++ };
  }

  // NOVO: gradi i salje addMark/removeMark za trenutnu selekciju (Sekcija 4.2 u radu).
  function toggleMark(markType, value) {
    const { start, end } = getSelectionTextOffsets();
    if (end <= start) return; // nema selekcije - nista da se formatira

    const firstId = crdtIdAtVisibleIndex(start);
    const lastId = crdtIdAtVisibleIndex(end - 1);
    if (!firstId || !lastId) return;

    const shouldRemove = isRangeFullyMarked(start, end, markType);
    const opId = makeOpId();

    let op;
    if (shouldRemove) {
      op = {
        opId,
        markType,
        isRemove: true,
        start: { id: firstId, anchorType: "After" },
        end: { id: lastId, anchorType: "Before" },
      };
    } else {
      const behavior = MARK_BEHAVIOR[markType] || "expanding";
      const nextId = findVisibleElementAt(end); // karakter odmah posle selekcije, ili null
      const endAnchor =
        behavior === "expanding"
          ? { id: nextId ? nextId.crdtId : null, anchorType: "Before" }
          : { id: lastId, anchorType: "After" };

      op = {
        opId,
        markType,
        isRemove: false,
        start: { id: firstId, anchorType: "Before" },
        end: endAnchor,
        value: value ?? null,
      };
    }

    localMarks.push(op);
    connection.invoke("SendMark", op, docId);
  }

  // NOVO: presrecemo TinyMCE-ove UGRADJENE Bold/Italic/Underline komande (dugmad u default
  // toolbar-u, meniju I precice Ctrl+B/Ctrl+I/Ctrl+U rade preko ovih komandi), tako da ne
  // moramo nista da menjamo u index.html niti da dupliramo toolbar dugmad. Sprecavamo
  // podrazumevano DOM formatiranje i umesto toga generisemo Peritext addMark/removeMark.
  editor.on("BeforeExecCommand", (e) => {
    const markType = { Bold: "bold", Italic: "italic", Underline: "underline" }[e.command];
    if (!markType) return;

    e.preventDefault();
    toggleMark(markType);
  });

  editor.on("init", () => {
    connection = new signalR.HubConnectionBuilder()
      .withUrl(hubUrl)
      .withAutomaticReconnect()
      .build();

    // PROMENA: "ElementsChanged" -> "DocumentChanged" (elements, marks, spans). Server je
    // sad jedini izvor istine za formatiranje - klijent samo renderuje spans.
    connection.on("DocumentChanged", (elements, marks, spans) => {
      localElements = elements;
      localMarks = marks;
      localSpans = spans;
      isApplyingRemoteChange = true;
      editor.setContent(spansToHtml(spans));
      isApplyingRemoteChange = false;
    });

    connection
      .start()
      .then(() => connection.invoke("JoinDocument", docId))
      .then(() => {
        console.log("[crdtsync] was connected, myNodeId = ", myNodeId);
      })
      .catch((err) => console.error("[crdtsync] error during connection", err));
  });

  editor.on("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      editor.execCommand("InsertParagraph");
    }
    if (e.key === "Tab") {
      e.preventDefault();
      editor.insertContent("&nbsp;&nbsp;&nbsp;&nbsp;");
    }
  });

  editor.on("input", () => {
    if (isApplyingRemoteChange) {
      return;
    }

    const newText = editor.getContent({ format: "text" });
    const oldText = renderText();

    const { start, deleted, inserted } = diffText(oldText, newText);

    for (let i = 0; i < deleted.length; i++) {
      const el = findVisibleElementAt(start);
      if (!el) continue;
      el.isDeleted = true;
      connection.invoke("Delete", el.crdtId, docId);
    }

    for (let i = 0; i < inserted.length; i++) {
      const predecessorId = findPredecessorId(start + i);
      const successorElement = findVisibleElementAt(start + i);
      const successorId = successorElement ? successorElement.crdtId : null;
      const newElement = {
        crdtId: { nodeId: myNodeId, counter: myCounter++ },
        value: inserted[i],
        predecessorId,
        successorId,
        isDeleted: false,
      };

      const insertAt = predecessorId
        ? localElements.findIndex((e) => idsEqual(e.crdtId, predecessorId)) + 1
        : 0;
      localElements.splice(insertAt, 0, newElement);

      connection.invoke("Insert", newElement, docId);
    }
  });

  return {
    getMetadata: () => ({ name: "CRDT Sync" }),
  };
});
