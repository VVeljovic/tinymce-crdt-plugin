# Peritext patch za tinymce-crdt-plugin

Ovo je prvi konkretan korak ka uvodjenju Peritext algoritma (Litt, Lim, Kleppmann,
van Hardenberg - "Peritext: A CRDT for Collaborative Rich Text Editing", CSCW 2022) u tvoj
projekat. Fajlovi ovde prate strukturu tvog solution-a 1:1 - kopiraj ih preko postojecih
(ili poredi/mergujes rucno, sto god ti odgovara).

## Sta je novo / promenjeno

**CrdtCore/**
- `CrdtAnchor.cs` - IZMENJEN: `Id` je sad nullable (`CrdtId?`), da bi mogao da predstavlja
  pocetak/kraj celog dokumenta (Peritextov "startOfText"/"endOfText", Sekcija 4.2.2).
- `MarkTypes.cs` - NOV: registar tipova formatiranja (bold, italic, underline, color, link,
  comment) sa dva parametra iz Tabele 1 u radu - da li mark moze da se preklapa i da li raste
  na granici spana.
- `CrdtMarkOperation.cs` - NOV: addMark/removeMark operacija + fabricke metode koje same
  biraju before/after stranu anchora prema pravilima iz Sekcije 4.2.
- `CrdtFormatting.cs` - ZAMENjEN (bio je prazan stub): algoritam koji iz istorije marks
  operacija racuna trenutne formatirane spanove (Sekcija 4.3-4.4, "from-scratch" varijanta).
- `CrdtDocument.cs` - IZMENJEN: dodat `Marks` niz, `ApplyMark`, `GetNextVisibleElementId`,
  `GetFormattedSpans()`.

**CrdtCore.Tests/**
- `CrdtFormattingTests.cs` - NOV: testovi prepisani iz Primera 1, 2, 3, 7, 8 iz rada plus
  test za preklapajuce komentare.

**CrdtServer/**
- `protobuf.proto` - IZMENJEN: dodate `CrdtAnchor`, `CrdtMarkOperation`,
  `MarkOperationMessage` poruke i `MarkOperation` rpc (analogno Insert/Delete).
- `PeerSyncClient.cs` - IZMENJEN: dodat `BroadcastMarkAsync` (peer-to-peer prosledjivanje
  mark operacija preko gRPC-a, isti obrazac kao insert/delete).
- `Services/CrdtService.cs` - IZMENJEN: dodat `MarkOperation` gRPC handler.
- `CrdtHub.cs` - IZMENJEN:
  - dodat `SendMark` hub metod (klijent -> server -> ostali klijenti + peer-ovi);
  - dogadjaj `"ElementsChanged"` je preimenovan u `"DocumentChanged"` i sad nosi
    `(elements, marks, spans)` - `spans` je vec izracunato formatiranje
    (`CrdtFormatting.ComputeSpans`), tako da klijent ne mora da duplira algoritam u JS-u;
  - `Insert`/`Delete` sad emituju `Clients.Group(...)` umesto `Clients.GroupExcept(...)` -
    posiljalac takodje dobija echo nazad, sto pojednostavljuje klijenta (uvek samo renderuje
    ono sto server posalje, nema lokalne "optimisticne" verzije formatiranja).

**crdtsync.js** - IZMENJEN:
- prati `localMarks` i `localSpans` pored `localElements`;
- presrece ugradjene TinyMCE Bold/Italic/Underline komande (`BeforeExecCommand`) i umesto
  podrazumevanog DOM formatiranja generise addMark/removeMark operacije i salje ih na
  `SendMark` - ovo znaci da NIJE potrebno menjati toolbar u `index.html`, Ctrl+B/Ctrl+I i
  dalje rade kao i pre;
  - `spansToHtml` pretvara serverom izracunate spans u HTML (`<strong>`, `<em>`, `<u>`,
  `<a>`, `<span style="color:...">`), paragraf-split je i dalje naivan (na `\n`), kao u
  originalu - Peritext namerno ne pokriva block-level formatiranje (Sekcija 5 u radu).

`index.html` nije menjan - nije potreban.

## Sta NIJE uradjeno (sledeci koraci)

- Komentari (`MarkTypes.Comment`) imaju gotov model u `CrdtCore` (`AddComment`/
  `RemoveComment`, testirano u `CrdtFormattingTests`), ali nema UI-a u `crdtsync.js` da ih
  kreira/prikaze - to bi trebalo tekst-selekciju + custom toolbar dugme + prikaz highlight-a.
- Boja teksta (`MarkTypes.Color`) ima render podrsku (`spansToHtml`) ali nema UI za biranje
  boje.
- `CrdtFormatting.ComputeSpans` je "from-scratch" (O(broj karaktera x broj mark operacija)
  po pozivu) - dovoljno brzo za prototip/demo, ali za veci dokument vredi preci na
  inkrementalni pristup iz Sekcije 4.5 rada (Algorithm 1).
- Block-level formatiranje (naslovi, liste, block quote, tabele) namerno nije pokriveno -
  sam Peritext rad to ostavlja za buduci rad (Sekcija 5).

## Kako da ovo uklopis

1. Prekopiraj fajlove preko odgovarajucih u `CrdtCore/`, `CrdtCore.Tests/`, `CrdtServer/`
   (ukljucujuci `Services/`) i preko `crdtsync.js` u korenu projekta.
2. Build ce ponovo generisati C# klase iz `protobuf.proto` (Grpc.Tools paket to radi
   automatski pri build-u, kao i do sada).
3. Pokreni `CrdtCore.Tests` - novi testovi bi trebalo da prodju.
4. Pokreni `CrdtServer` + `index.html` kao i do sada; probaj da selektujes tekst i pritisnes
   Ctrl+B u dva browser taba istovremeno da vidis da li se markovi ispravno spajaju.
