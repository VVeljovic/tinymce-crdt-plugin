namespace CrdtCore
{
    /// <summary>
    /// Anchor pozicija iz Peritext algoritma (Sekcija 4.2 / Fig. 3 u radu): svaki karakter ima
    /// dve moguce "kuke" za formatiranje - odmah PRE i odmah POSLE njega. addMark/removeMark
    /// operacije se ne vezuju za indekse u tekstu nego za ove anchor-e, sto ostaje stabilno
    /// bez obzira na concurrent insert/delete operacije.
    ///
    /// Id je namerno nullable: Id == null oznacava granicu dokumenta (pocetak ako je
    /// Type == Before, kraj ako je Type == After) - ovo je Peritextov "startOfText"/"endOfText"
    /// slucaj iz Sekcije 4.2.2, za marks koji pokrivaju ceo dokument od/do kraja.
    /// </summary>
    public sealed record CrdtAnchor(CrdtId? Id, AnchorType Type)
    {
        public static CrdtAnchor Before(CrdtId? id) => new(id, AnchorType.Before);
        public static CrdtAnchor After(CrdtId? id) => new(id, AnchorType.After);

        public static CrdtAnchor StartOfText => new(null, AnchorType.Before);
        public static CrdtAnchor EndOfText => new(null, AnchorType.After);
    }
}
