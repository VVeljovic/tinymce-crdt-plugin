namespace CrdtCore
{
    /// <summary>
    /// addMark / removeMark operacija (Sekcija 4.2 u radu). Format prati operaciju iz rada
    /// gotovo 1:1:
    ///
    ///   { action: "addMark", opId, start: {type, opId}, end: {type, opId}, markType, value? }
    ///
    /// Za "Overlapping" mark tipove (komentar) Start/End se ne koriste za LWW razresenje
    /// konflikta (vise komentara sme da koegzistira) - umesto toga RemoveMark referencira
    /// TargetOpId, tj. OpId konkretnog AddMark-a (komentara) koji se brise. Ovo je namerna
    /// razlika u odnosu na algoritam iz rada: rad ne razradjuje kako se pojedinacni
    /// komentar precizno uklanja (samo pominje da LWW nije prikladan za komentare, Sekcija 3.2.2
    /// i 4.4), pa je ovo najjednostavnije korektno resenje za taj slucaj.
    /// </summary>
    public sealed record CrdtMarkOperation
    {
        public required CrdtId OpId { get; init; }
        public required string MarkType { get; init; }
        public required bool IsRemove { get; init; }

        // Koristi se za Exclusive mark tipove (bold, italic, link, boja...).
        public CrdtAnchor? Start { get; init; }
        public CrdtAnchor? End { get; init; }

        // Koristi se za Overlapping mark tipove (komentar) - vidi napomenu iznad.
        public CrdtId? TargetOpId { get; init; }

        // Dodatni podatak uz mark: URL za link, boja, tekst/id komentara...
        public string? Value { get; init; }
    }

    /// <summary>
    /// Pomocne fabricke metode koje same biraju before/after stranu anchora u zavisnosti od
    /// MarkBehavior-a datog markType-a, tacno prema pravilima iz Sekcije 4.2 i 4.2.2:
    ///  - addMark: start = Before(prviKarakter); end = Before(sledeciKarakterPoSpanu) za
    ///    Expanding markove (bold/italic/boja...), ili After(poslednjiKarakter) za
    ///    NonExpanding markove (link) - to je razlog zasto link ne raste kad se doda tekst
    ///    na kraju spana.
    ///  - removeMark: uvek okrece strane u odnosu na addMark (start=After, end=Before) -
    ///    ovo garantuje da naknadno umetnut tekst nasledi ispravno stanje formatiranja
    ///    (Sekcija 4.2.1).
    /// </summary>
    public static class CrdtMarkOperationFactory
    {
        public static CrdtMarkOperation AddMark(
            CrdtId opId,
            CrdtId firstCharId,
            CrdtId lastCharId,
            CrdtId? nextCharIdAfterSpan,
            string markType,
            string? value = null)
        {
            var behavior = MarkTypes.Get(markType).Behavior;

            var start = CrdtAnchor.Before(firstCharId);
            var end = behavior == MarkBehavior.Expanding
                ? (nextCharIdAfterSpan is not null ? CrdtAnchor.Before(nextCharIdAfterSpan) : CrdtAnchor.EndOfText)
                : CrdtAnchor.After(lastCharId);

            return new CrdtMarkOperation
            {
                OpId = opId,
                MarkType = markType,
                IsRemove = false,
                Start = start,
                End = end,
                Value = value
            };
        }

        public static CrdtMarkOperation RemoveMark(
            CrdtId opId,
            CrdtId firstCharId,
            CrdtId lastCharId,
            string markType)
        {
            return new CrdtMarkOperation
            {
                OpId = opId,
                MarkType = markType,
                IsRemove = true,
                Start = CrdtAnchor.After(firstCharId),
                End = CrdtAnchor.Before(lastCharId)
            };
        }

        public static CrdtMarkOperation AddComment(
            CrdtId opId,
            CrdtId firstCharId,
            CrdtId lastCharId,
            string? commentValue) =>
            new CrdtMarkOperation
            {
                OpId = opId,
                MarkType = MarkTypes.Comment,
                IsRemove = false,
                Start = CrdtAnchor.Before(firstCharId),
                End = CrdtAnchor.After(lastCharId),
                Value = commentValue
            };

        public static CrdtMarkOperation RemoveComment(CrdtId opId, CrdtId commentOpId) =>
            new CrdtMarkOperation
            {
                OpId = opId,
                MarkType = MarkTypes.Comment,
                IsRemove = true,
                TargetOpId = commentOpId
            };
    }
}
