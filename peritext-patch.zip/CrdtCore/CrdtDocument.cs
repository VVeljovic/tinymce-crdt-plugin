namespace CrdtCore
{
    public class CrdtDocument
    {
        public List<CrdtElement> Elements { get; set; } = [];

        // NOVO: append-only istorija addMark/removeMark operacija (Sekcija 4.2 u radu).
        // Namerno odvojeno od Elements - formatiranje se ne lepi na karaktere, vec se cuva
        // kao nezavisan log koji se referencira preko stabilnih CrdtId anchora.
        public List<CrdtMarkOperation> Marks { get; set; } = [];

        public CrdtDocument() { }

        private int FindElementIndexById(CrdtId? crdtId)
        {
            if (crdtId == null)
            {
                return -1;
            }

            for (int i = 0; i < Elements.Count; i++)
            {
                if (Elements[i].CrdtId == crdtId)
                {
                    return i;
                }
            }
            return -1;
        }

        public CrdtElement Insert(CrdtElement crdtElement)
        {
            InsertElementInOrder(crdtElement);

            return crdtElement;
        }

        private void InsertElementInOrder(CrdtElement newElement)
        {
            var insertAfterIndex = FindElementIndexById(newElement.PredecessorId);
            var candidateIndex = insertAfterIndex + 1;

            var successorIndex = FindElementIndexById(newElement.SuccessorId);
            var boundIndex = newElement.SuccessorId != null && successorIndex >= 0 ? successorIndex : Elements.Count;

            var skippedIds = new HashSet<CrdtId?> { newElement.PredecessorId };

            while (candidateIndex < boundIndex)
            {
                var candidate = Elements[candidateIndex];

                bool partOfConflicts = skippedIds.Contains(candidate.PredecessorId);

                if (!partOfConflicts)
                    break;

                if (candidate.PredecessorId == newElement.PredecessorId
                    && candidate.CrdtId.CompareTo(newElement.CrdtId) <= 0) // exit when new element has priority
                    break;

                skippedIds.Add(candidate.CrdtId);
                candidateIndex++;
            }

            Elements.Insert(candidateIndex, newElement);
        }


        public CrdtElement? Delete(CrdtId targetId)
        {
            var elementToDelete = Elements.FirstOrDefault(e => e.CrdtId == targetId);

            if (elementToDelete == null)
            {
                return null;
            }

            elementToDelete.IsDeleted = true;

            return elementToDelete;
        }

        public string GetText() => string.Join("", Elements.Where(x => !x.IsDeleted).Select(x => x.Value));

        // NOVO: prima addMark/removeMark operaciju. Namerno bez validacije/dedupe - Peritext
        // operacije su append-only i idempotentne u odnosu na konacan rezultat (dodavanje
        // iste operacije dva puta ne menja formatiranje), pa je najjednostavnije da se ovde
        // samo cuvaju, a CrdtFormatting.ComputeSpans racuna posledice.
        public CrdtMarkOperation ApplyMark(CrdtMarkOperation markOperation)
        {
            Marks.Add(markOperation);
            return markOperation;
        }

        // Pomocna metoda za klijenta/hub: kad se kreira addMark operacija za span koji se
        // zavrsava na lastCharId, ovo daje CrdtId sledeceg VIDLJIVOG karaktera posle njega
        // (potrebno za "Expanding" markove - Primer 7/8, Sekcija 4.2.2). Vraca null ako je
        // lastCharId trenutno poslednji vidljivi karakter u dokumentu.
        public CrdtId? GetNextVisibleElementId(CrdtId lastCharId)
        {
            var idx = FindElementIndexById(lastCharId);
            if (idx < 0) return null;

            for (int i = idx + 1; i < Elements.Count; i++)
            {
                if (!Elements[i].IsDeleted)
                    return Elements[i].CrdtId;
            }
            return null;
        }

        // NOVO: izvodi trenutno formatiranje iz istorije marks operacija (Sekcija 4.4).
        public List<FormattedSpan> GetFormattedSpans() => CrdtFormatting.ComputeSpans(this);
    }
}
