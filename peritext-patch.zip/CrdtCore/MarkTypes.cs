namespace CrdtCore
{
    /// <summary>
    /// Da li vise markova istog tipa moze da postoji istovremeno na istom karakteru
    /// (Tabela 1 u radu, kolona "Can marks overlap?").
    /// - Exclusive: bold, italic, boja, link... - konflikt se resava last-write-wins
    ///   (poredjenje po OpId, vidi CrdtFormatting).
    /// - Overlapping: komentari - vise razlicitih komentara moze da pokriva isti karakter.
    /// </summary>
    public enum MarkCategory
    {
        Exclusive,
        Overlapping
    }

    /// <summary>
    /// Da li mark "raste" kada se novi tekst ubaci tacno na granicu spana
    /// (Tabela 1, kolona "Do marks expand?"; Primeri 7 i 8 u radu).
    /// Bold/italic/boja rastu; linkovi (i komentari) ne rastu.
    /// </summary>
    public enum MarkBehavior
    {
        Expanding,
        NonExpanding
    }

    public sealed record MarkTypeInfo(string Name, MarkCategory Category, MarkBehavior Behavior);

    /// <summary>
    /// Registar poznatih tipova formatiranja. Ovo namerno NIJE zatvoren enum (kao sto
    /// AnchorType jeste) - u radu se eksplicitno kaze da je svaki mark tip samo kombinacija
    /// ova dva parametra (Sekcija 3.4), pa je lakse da ostane prosirivo (npr. dodavanje
    /// "strikethrough" ili "font-size" kasnije ne trazi menjanje CrdtFormatting algoritma).
    /// </summary>
    public static class MarkTypes
    {
        public const string Bold = "bold";
        public const string Italic = "italic";
        public const string Underline = "underline";
        public const string Color = "color";
        public const string Link = "link";
        public const string Comment = "comment";

        private static readonly Dictionary<string, MarkTypeInfo> _registry = new()
        {
            [Bold] = new(Bold, MarkCategory.Exclusive, MarkBehavior.Expanding),
            [Italic] = new(Italic, MarkCategory.Exclusive, MarkBehavior.Expanding),
            [Underline] = new(Underline, MarkCategory.Exclusive, MarkBehavior.Expanding),
            [Color] = new(Color, MarkCategory.Exclusive, MarkBehavior.Expanding),
            [Link] = new(Link, MarkCategory.Exclusive, MarkBehavior.NonExpanding),
            [Comment] = new(Comment, MarkCategory.Overlapping, MarkBehavior.NonExpanding),
        };

        public static MarkTypeInfo Get(string markType) =>
            _registry.TryGetValue(markType, out var info)
                ? info
                : new MarkTypeInfo(markType, MarkCategory.Exclusive, MarkBehavior.Expanding); // razumna podrazumevana vrednost

        /// <summary>Registruje novi custom mark tip (npr. font-size) pre upotrebe.</summary>
        public static void Register(MarkTypeInfo info) => _registry[info.Name] = info;
    }
}
