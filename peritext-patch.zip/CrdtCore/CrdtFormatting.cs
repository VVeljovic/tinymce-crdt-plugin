namespace CrdtCore
{
    /// <summary>
    /// Jedan "span" formatiranog teksta - niz susednih karaktera sa identicnim formatiranjem
    /// (Sekcija 4.4 u radu, primer izlaza: [{text:"The ", format:{bold:true}}, ...]).
    /// </summary>
    public sealed record FormattedSpan(
        string Text,
        IReadOnlyDictionary<string, string?> Marks,
        IReadOnlyList<CrdtId> CommentIds);

    /// <summary>
    /// Peritext algoritam za izvodjenje TRENUTNOG formatiranja iz kompletne istorije
    /// addMark/removeMark operacija (Sekcije 4.3-4.4 rada).
    ///
    /// Ovo je namerno "from-scratch" varijanta (ne inkrementalna iz Sekcije 4.5): pri
    /// svakom pozivu prolazi kroz ceo dokument. To je dovoljno brzo za prototip i uklapa se
    /// u trenutni model gde server svakako drzi/salje kompletno stanje dokumenta klijentima
    /// (CrdtHub vec salje ceo Elements niz). Ako performanse na velikim dokumentima postanu
    /// problem, ovo mesto zamenite Algorithm 1 iz rada (op-set po anchor poziciji, azuriran
    /// inkrementalno pri svakoj primenjenoj operaciji).
    ///
    /// Kljucna osobina koju ova implementacija cuva: pozicije se racunaju iz TRENUTNOG
    /// redosleda elemenata (Elements), a ne iz stanja u trenutku kad je mark kreiran - zato
    /// concurrent insert unutar opsega automatski nasledi formatiranje (Primer 1 u radu),
    /// bez ikakve posebne logike za to.
    /// </summary>
    public static class CrdtFormatting
    {
        public static List<FormattedSpan> ComputeSpans(CrdtDocument document)
        {
            var elements = document.Elements.Where(e => !e.IsDeleted).ToList();
            int n = elements.Count;

            var indexById = new Dictionary<CrdtId, int>(n);
            for (int i = 0; i < n; i++)
                indexById[elements[i].CrdtId] = i;

            // Gap g (0..n) je "prostor" izmedju elements[g-1] i elements[g]; gap 0 je pocetak
            // teksta, gap n je kraj teksta. Anchor{Id=X, Before} => gap = index(X).
            // Anchor{Id=X, After} => gap = index(X)+1. Anchor{Id=null,...} => granica dokumenta.
            int GapOf(CrdtAnchor? anchor, bool isStartBoundary)
            {
                if (anchor?.Id is null)
                    return isStartBoundary ? 0 : n;

                if (!indexById.TryGetValue(anchor.Id, out var idx))
                    return isStartBoundary ? 0 : n; // karakter je tombstone/nepoznat - bezbedan fallback

                return anchor.Type == AnchorType.Before ? idx : idx + 1;
            }

            // --- Exclusive markovi (bold, italic, boja, link...): LWW po najvecem OpId ---
            var exclusiveOps = document.Marks
                .Where(m => m.Start is not null && m.End is not null
                            && MarkTypes.Get(m.MarkType).Category == MarkCategory.Exclusive)
                .Select(m => (Op: m, Start: GapOf(m.Start, true), End: GapOf(m.End, false)))
                .ToList();

            var exclusiveTypes = exclusiveOps.Select(x => x.Op.MarkType).Distinct().ToList();

            // --- Overlapping markovi (komentar): svaki AddMark je svoja nezavisna stavka,
            // uklanja se iskljucivo preko TargetOpId koji referencira RemoveMark ---
            var commentAdds = document.Marks
                .Where(m => !m.IsRemove && MarkTypes.Get(m.MarkType).Category == MarkCategory.Overlapping
                            && m.Start is not null && m.End is not null)
                .ToDictionary(m => m.OpId, m => (Start: GapOf(m.Start, true), End: GapOf(m.End, false), m.Value));

            foreach (var removeOp in document.Marks.Where(m => m.IsRemove && m.TargetOpId is not null))
                commentAdds.Remove(removeOp.TargetOpId!);

            var spans = new List<FormattedSpan>();
            var sb = new System.Text.StringBuilder();
            IReadOnlyDictionary<string, string?>? currentMarks = null;
            IReadOnlyList<CrdtId>? currentComments = null;

            for (int g = 0; g < n; g++)
            {
                var marks = new Dictionary<string, string?>();
                foreach (var markType in exclusiveTypes)
                {
                    CrdtMarkOperation? winner = null;
                    foreach (var (op, s, e) in exclusiveOps)
                    {
                        if (op.MarkType != markType) continue;
                        if (s <= g && g < e && (winner is null || op.OpId.CompareTo(winner.OpId) > 0))
                            winner = op;
                    }
                    if (winner is not null && !winner.IsRemove)
                        marks[markType] = winner.Value ?? "true";
                }

                var comments = commentAdds
                    .Where(kv => kv.Value.Start <= g && g < kv.Value.End)
                    .Select(kv => kv.Key)
                    .OrderBy(id => id)
                    .ToList();

                bool sameAsCurrent = currentMarks is not null
                    && MarksEqual(currentMarks, marks)
                    && currentComments!.SequenceEqual(comments);

                if (!sameAsCurrent && sb.Length > 0)
                {
                    spans.Add(new FormattedSpan(sb.ToString(), currentMarks!, currentComments!));
                    sb.Clear();
                }

                sb.Append(elements[g].Value);
                currentMarks = marks;
                currentComments = comments;
            }

            if (sb.Length > 0)
                spans.Add(new FormattedSpan(sb.ToString(), currentMarks!, currentComments!));

            return spans;
        }

        private static bool MarksEqual(IReadOnlyDictionary<string, string?> a, IReadOnlyDictionary<string, string?> b) =>
            a.Count == b.Count && a.All(kv => b.TryGetValue(kv.Key, out var v) && v == kv.Value);
    }
}
