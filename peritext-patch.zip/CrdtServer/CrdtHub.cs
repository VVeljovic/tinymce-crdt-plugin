using CrdtServer;
using CrdtServer.Services;
using Microsoft.AspNetCore.SignalR;

public class CrdtHub(CrdtDocumentStore store, PeerSyncClient peerSyncClient) : Hub
{
    public async Task JoinDocument(string docId)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, docId);

        var document = store.GetOrCreate(docId);

        // PROMENA: "ElementsChanged" -> "DocumentChanged" - sad salje i marks i vec izracunate
        // formatted spans, tako da klijent ne mora da ponavlja CrdtFormatting algoritam u JS-u
        // (server ostaje jedini izvor istine za formatiranje - videti napomenu u crdtsync.js).
        await Clients.Caller.SendAsync("DocumentChanged",
            document.Elements, document.Marks, document.GetFormattedSpans());
    }

    public async Task Insert(CrdtCore.CrdtElement crdtElement, string docId)
    {
        var document = store.GetOrCreate(docId);

        document.Insert(crdtElement);

        // PROMENA: Clients.Group (ne GroupExcept) - pozivalac dobija svoj sopstveni echo
        // nazad. Ovo je namerna pojednostavitev: pozivalac vec ima lokalnu kopiju elemenata
        // (localElements u crdtsync.js), ali otkad server racuna i formatiranje, najjednostavnije
        // je da svi klijenti (ukljucujuci pozivaoca) uvek renderuju ono sto server posalje,
        // umesto da pozivalac drzi svoju paralelnu "optimisticnu" verziju formatiranja.
        await Clients.Group(docId).SendAsync("DocumentChanged",
            document.Elements, document.Marks, document.GetFormattedSpans());

        await peerSyncClient.BroadcastInsertAsync(ToWireElement(crdtElement), docId);
    }

    public async Task Delete(CrdtCore.CrdtId crdtId, string docId)
    {
        var document = store.GetOrCreate(docId);

        document.Delete(crdtId);

        await Clients.Group(docId).SendAsync("DocumentChanged",
            document.Elements, document.Marks, document.GetFormattedSpans());

        await peerSyncClient.BroadcastDeleteAsync(ToWireId(crdtId), docId);
    }

    // NOVO: analogno Insert/Delete - prima addMark/removeMark operaciju od klijenta.
    public async Task SendMark(CrdtCore.CrdtMarkOperation markOperation, string docId)
    {
        var document = store.GetOrCreate(docId);

        document.ApplyMark(markOperation);

        await Clients.Group(docId).SendAsync("DocumentChanged",
            document.Elements, document.Marks, document.GetFormattedSpans());

        await peerSyncClient.BroadcastMarkAsync(ToWireMarkOperation(markOperation), docId);
    }

    private static CrdtId ToWireId(CrdtCore.CrdtId id) =>
        new CrdtId { NodeId = id.NodeId, Counter = id.Counter };

    private static CrdtElement ToWireElement(CrdtCore.CrdtElement element) =>
        new CrdtElement
        {
            Id = ToWireId(element.CrdtId),
            Value = element.Value.ToString(),
            PredecessorId = element.PredecessorId != null ? ToWireId(element.PredecessorId) : null,
            SuccessorId = element.SuccessorId != null ? ToWireId(element.SuccessorId) : null,
            IsDeleted = element.IsDeleted
        };

    private static CrdtAnchor? ToWireAnchor(CrdtCore.CrdtAnchor? anchor) =>
        anchor is null
            ? null
            : new CrdtAnchor
            {
                Id = anchor.Id != null ? ToWireId(anchor.Id) : null,
                AnchorType = anchor.Type == CrdtCore.AnchorType.After ? WireAnchorType.After : WireAnchorType.Before
            };

    private static CrdtMarkOperation ToWireMarkOperation(CrdtCore.CrdtMarkOperation op) =>
        new CrdtMarkOperation
        {
            OpId = ToWireId(op.OpId),
            MarkType = op.MarkType,
            IsRemove = op.IsRemove,
            Start = ToWireAnchor(op.Start),
            End = ToWireAnchor(op.End),
            TargetOpId = op.TargetOpId != null ? ToWireId(op.TargetOpId) : null,
            Value = op.Value ?? string.Empty
        };
}
