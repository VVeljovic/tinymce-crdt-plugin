using Grpc.Core;
using Microsoft.AspNetCore.SignalR;

namespace CrdtServer.Services
{
    public class CrdtService : CrdtServer.CrdtService.CrdtServiceBase
    {
        private readonly CrdtDocumentStore _store;
        private readonly ILogger<CrdtService> _logger;
        private readonly IHubContext<CrdtHub> _hubContext;

        public CrdtService(CrdtDocumentStore store, ILogger<CrdtService> logger, IHubContext<CrdtHub> hubContext)
        {
            _store = store;
            _logger = logger;
            _hubContext = hubContext;
        }

        public override async Task InsertOperation(IAsyncStreamReader<InsertOperationMessage> requestStream,
            IServerStreamWriter<InsertOperationMessage> responseStream,
            ServerCallContext context)
        {
            await foreach (var message in requestStream.ReadAllAsync(context.CancellationToken))
            {
                if (string.IsNullOrEmpty(message.Element.Value))
                {
                    _logger.LogWarning("Ignored InsertElement with empty value for doc '{DocId}'.", message.DocId);
                    continue;
                }

                var document = _store.GetOrCreate(message.DocId);
                document.Insert(ToDomainElement(message.Element));

                await _hubContext.Clients.Group(message.DocId).SendAsync("DocumentChanged",
                    document.Elements, document.Marks, document.GetFormattedSpans());

                _logger.LogInformation(
                    "Applied peer insert '{Value}' at index {Index} on doc '{DocId}'.",
                    message.Element.Value, message.Element.Id, message.DocId);
            }
        }

        public override async Task DeleteOperation(IAsyncStreamReader<DeleteOperationMessage> requestStream,
            IServerStreamWriter<DeleteOperationMessage> responseStream,
            ServerCallContext context)
        {
            await foreach (var message in requestStream.ReadAllAsync(context.CancellationToken))
            {
                var document = _store.GetOrCreate(message.DocId);
                document.Delete(ToDomainId(message.ElementId));

                await _hubContext.Clients.Group(message.DocId).SendAsync("DocumentChanged",
                    document.Elements, document.Marks, document.GetFormattedSpans());

                _logger.LogInformation(
                    "Applied peer delete at index {Index} on doc '{DocId}'.",
                    message.ElementId, message.DocId);
            }
        }

        // NOVO: analogno InsertOperation/DeleteOperation - prima addMark/removeMark od peer-a.
        public override async Task MarkOperation(IAsyncStreamReader<MarkOperationMessage> requestStream,
            IServerStreamWriter<MarkOperationMessage> responseStream,
            ServerCallContext context)
        {
            await foreach (var message in requestStream.ReadAllAsync(context.CancellationToken))
            {
                var document = _store.GetOrCreate(message.DocId);
                document.ApplyMark(ToDomainMarkOperation(message.Operation));

                await _hubContext.Clients.Group(message.DocId).SendAsync("DocumentChanged",
                    document.Elements, document.Marks, document.GetFormattedSpans());

                _logger.LogInformation(
                    "Applied peer {Action} mark '{MarkType}' on doc '{DocId}'.",
                    message.Operation.IsRemove ? "removeMark" : "addMark", message.Operation.MarkType, message.DocId);
            }
        }

        private static CrdtCore.CrdtId ToDomainId(CrdtId protoId) => new(protoId.NodeId, protoId.Counter);

        private static CrdtCore.CrdtElement ToDomainElement(CrdtElement protoElement) => new CrdtCore.CrdtElement
        {
            CrdtId = ToDomainId(protoElement.Id),
            Value = protoElement.Value[0],
            PredecessorId = protoElement.PredecessorId != null ? ToDomainId(protoElement.PredecessorId) : null,
            SuccessorId = protoElement.SuccessorId != null ? ToDomainId(protoElement.SuccessorId) : null,
            IsDeleted = protoElement.IsDeleted
        };

        private static CrdtCore.CrdtId? ToDomainIdOrNull(CrdtId? protoId) =>
            protoId != null ? ToDomainId(protoId) : null;

        private static CrdtCore.CrdtAnchor? ToDomainAnchor(CrdtAnchor? protoAnchor) =>
            protoAnchor is null
                ? null
                : new CrdtCore.CrdtAnchor(
                    ToDomainIdOrNull(protoAnchor.Id),
                    protoAnchor.AnchorType == WireAnchorType.After ? CrdtCore.AnchorType.After : CrdtCore.AnchorType.Before);

        private static CrdtCore.CrdtMarkOperation ToDomainMarkOperation(CrdtMarkOperation protoOp) => new()
        {
            OpId = ToDomainId(protoOp.OpId),
            MarkType = protoOp.MarkType,
            IsRemove = protoOp.IsRemove,
            Start = ToDomainAnchor(protoOp.Start),
            End = ToDomainAnchor(protoOp.End),
            TargetOpId = ToDomainIdOrNull(protoOp.TargetOpId),
            Value = string.IsNullOrEmpty(protoOp.Value) ? null : protoOp.Value
        };
    }
}
