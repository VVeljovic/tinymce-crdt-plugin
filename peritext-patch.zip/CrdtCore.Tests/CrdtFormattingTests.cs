namespace CrdtCore.Tests
{
    /// <summary>
    /// Testovi prepisani direktno iz scenarija u Peritext radu (Sekcija 3, "Criteria for
    /// intent preservation"), da bi se proverilo da CrdtFormatting.ComputeSpans daje isto
    /// ponasanje koje autori smatraju intent-preserving.
    /// </summary>
    public class CrdtFormattingTests
    {
        private static CrdtElement Char(CrdtId id, char value, CrdtId? predecessorId = null) =>
            new CrdtElement { CrdtId = id, Value = value, PredecessorId = predecessorId, IsDeleted = false };

        private static (CrdtDocument doc, Dictionary<char, CrdtId> ids) BuildDoc(string text, int nodeId = 1)
        {
            var doc = new CrdtDocument();
            var ids = new Dictionary<char, CrdtId>();
            CrdtId? prev = null;
            long counter = 0;

            foreach (var ch in text)
            {
                var id = new CrdtId(nodeId, counter++);
                doc.Insert(Char(id, ch, prev));
                ids[ch] = id; // OK za ove testove: sva slova u primerima su razlicita
                prev = id;
            }

            return (doc, ids);
        }

        private static string SpansToDebugString(List<FormattedSpan> spans) =>
            string.Join(" | ", spans.Select(s =>
                $"\"{s.Text}\"[{string.Join(",", s.Marks.Keys.OrderBy(k => k))}]"));

        [Fact]
        public void Example1_ConcurrentFormattingAndInsertion_NewTextInheritsFormatting()
        {
            // Arrange: "The fox jumped." pa Alice bold ceo tekst, Bob konkurentno ubaci "brown "
            var (doc, ids) = BuildDoc("The fox jumped.");

            var boldOp = CrdtMarkOperationFactory.AddMark(
                new CrdtId(1, 100), ids['T'], ids['.'], nextCharIdAfterSpan: null, MarkTypes.Bold);
            doc.ApplyMark(boldOp);

            // Bob je konkurentno ubacio "brown " posle "The " - simuliramo umetanje karaktera
            // sa PredecessorId = poslednje slovo "The " ('e'), sto ih po CRDT poretku stavlja
            // odmah posle 'e' bez obzira sto Alisin addMark vec postoji.
            var brown = "brown ";
            CrdtId? prev = ids['e'];
            foreach (var ch in brown)
            {
                var id = new CrdtId(2, prev!.Counter * 1000 + prev.NodeId); // proizvoljan jedinstven id
                doc.Insert(Char(id, ch, prev));
                prev = id;
            }

            // Act
            var spans = doc.GetFormattedSpans();

            // Assert: ceo tekst, ukljucujuci "brown ", treba da bude bold (Primer 1 u radu)
            Assert.Equal("The brown fox jumped.", doc.GetText());
            Assert.All(spans, s => Assert.Equal("true", s.Marks.GetValueOrDefault(MarkTypes.Bold)));
        }

        [Fact]
        public void Example2_OverlappingSameMark_ConvergesToFullyBold()
        {
            // Arrange: "The fox jumped." - Alice boldira "The fox", Bob boldira "fox jumped."
            var (doc, ids) = BuildDoc("The fox jumped.");

            var aliceBold = CrdtMarkOperationFactory.AddMark(
                new CrdtId(1, 100), ids['T'], ids[' '.Equals(' ') ? 'x' : 'x'], ids['j'], MarkTypes.Bold);
            // gornji poziv: span od 'T' do 'x' (u "fox"), sledeci karakter posle njega je 'j'
            doc.ApplyMark(aliceBold);

            var bobBold = CrdtMarkOperationFactory.AddMark(
                new CrdtId(2, 100), ids['f'], ids['.'], nextCharIdAfterSpan: null, MarkTypes.Bold);
            doc.ApplyMark(bobBold);

            // Act
            var spans = doc.GetFormattedSpans();

            // Assert: ceo tekst treba da bude bold
            Assert.All(spans, s => Assert.Equal("true", s.Marks.GetValueOrDefault(MarkTypes.Bold)));
        }

        [Fact]
        public void Example3_OverlappingDifferentMarks_MiddleWordGetsBoth()
        {
            // Arrange: "The fox jumped." - Alice boldira "The fox", Bob kurzivira "fox jumped."
            var (doc, ids) = BuildDoc("The fox jumped.");

            doc.ApplyMark(CrdtMarkOperationFactory.AddMark(
                new CrdtId(1, 100), ids['T'], ids['x'], ids['j'], MarkTypes.Bold));

            doc.ApplyMark(CrdtMarkOperationFactory.AddMark(
                new CrdtId(2, 100), ids['f'], ids['.'], nextCharIdAfterSpan: null, MarkTypes.Italic));

            // Act
            var spans = doc.GetFormattedSpans();

            // Assert: "fox" (izmedju f i x, ukljucujuci ih) treba da bude i bold i italic
            var foxSpan = spans.FirstOrDefault(s => s.Text.Contains("fox"));
            Assert.NotNull(foxSpan);
            Assert.Equal("true", foxSpan!.Marks.GetValueOrDefault(MarkTypes.Bold));
            Assert.Equal("true", foxSpan!.Marks.GetValueOrDefault(MarkTypes.Italic));
        }

        [Fact]
        public void Example7_BoldSpan_TextInsertedInsideStaysBold_TextInsertedBeforeStaysNonBold()
        {
            // Arrange: "fox jumped." je bold, ostatak nije
            var (doc, ids) = BuildDoc("fox jumped.");

            doc.ApplyMark(CrdtMarkOperationFactory.AddMark(
                new CrdtId(1, 100), ids['f'], ids['.'], nextCharIdAfterSpan: null, MarkTypes.Bold));

            // Umetanje "quick " PRE "fox" (predecessor = null, pocetak dokumenta)
            var quick = "quick ";
            CrdtId? prev = null;
            var firstNewId = default(CrdtId);
            foreach (var ch in quick)
            {
                var id = new CrdtId(2, ids.Count + quick.IndexOf(ch) + 1000);
                if (prev is null) firstNewId = id;
                doc.Insert(Char(id, ch, prev));
                prev = id;
            }

            // Act
            var spans = doc.GetFormattedSpans();

            // Assert: prefiks "quick " nije bold, "fox jumped." jeste
            Assert.Equal("quick fox jumped.", doc.GetText());
            var firstSpan = spans.First();
            Assert.False(firstSpan.Marks.ContainsKey(MarkTypes.Bold));
            Assert.Contains(spans, s => s.Text.Contains("fox") && s.Marks.GetValueOrDefault(MarkTypes.Bold) == "true");
        }

        [Fact]
        public void Example8_LinkDoesNotGrow_WhenTextAppendedRightAfterLastLinkChar()
        {
            // Arrange: "fox jumped" je link (napomena: end = After(poslednje slovo 'd'), pa link
            // ne raste - za razliku od bold-a u Example7 gde je end = Before(sledeceg karaktera))
            var (doc, ids) = BuildDoc("fox jumped.");

            doc.ApplyMark(CrdtMarkOperationFactory.AddMark(
                new CrdtId(1, 100), ids['f'], ids['d'], nextCharIdAfterSpan: ids['.'],
                MarkTypes.Link, value: "https://example.com"));

            // Umetanje " over the dog" izmedju 'd' (poslednje slovo "jumped") i '.'
            var appended = " over the dog";
            CrdtId? prev = ids['d'];
            foreach (var ch in appended)
            {
                var id = new CrdtId(2, 5000 + appended.IndexOf(ch));
                doc.Insert(Char(id, ch, prev));
                prev = id;
            }

            // Act
            var spans = doc.GetFormattedSpans();

            // Assert: ubaceni tekst NIJE deo linka (Primer 8 u radu)
            var appendedSpan = spans.LastOrDefault(s => s.Text.Contains("over"));
            Assert.NotNull(appendedSpan);
            Assert.False(appendedSpan!.Marks.ContainsKey(MarkTypes.Link));

            var linkSpan = spans.First(s => s.Text.Contains("jumped"));
            Assert.Equal("https://example.com", linkSpan.Marks.GetValueOrDefault(MarkTypes.Link));
        }

        [Fact]
        public void MultipleOverlappingComments_BothRetainedUntilExplicitlyRemoved()
        {
            // Arrange: "The fox jumped." - Alice komentarise "The fox", Bob komentarise "fox jumped."
            var (doc, ids) = BuildDoc("The fox jumped.");

            var aliceComment = CrdtMarkOperationFactory.AddComment(
                new CrdtId(1, 100), ids['T'], ids['x'], commentValue: "alice-comment-1");
            var bobComment = CrdtMarkOperationFactory.AddComment(
                new CrdtId(2, 100), ids['f'], ids['.'], commentValue: "bob-comment-1");

            doc.ApplyMark(aliceComment);
            doc.ApplyMark(bobComment);

            // Act
            var spansBeforeRemoval = doc.GetFormattedSpans();
            var foxSpanBefore = spansBeforeRemoval.First(s => s.Text.Contains("fox"));

            doc.ApplyMark(CrdtMarkOperationFactory.RemoveComment(new CrdtId(1, 200), aliceComment.OpId));
            var spansAfterRemoval = doc.GetFormattedSpans();
            var foxSpanAfter = spansAfterRemoval.First(s => s.Text.Contains("fox"));

            // Assert: pre brisanja "fox" ima oba komentara, posle brisanja samo Bobov
            Assert.Equal(2, foxSpanBefore.CommentIds.Count);
            Assert.Single(foxSpanAfter.CommentIds);
            Assert.Equal(bobComment.OpId, foxSpanAfter.CommentIds[0]);
        }
    }
}
